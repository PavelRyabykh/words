<?php echo e($slot); ?>

<?php /**PATH /home/projects/words.loc/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>