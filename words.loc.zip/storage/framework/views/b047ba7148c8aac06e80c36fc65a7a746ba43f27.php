<section class="jumbotron text-center pt-3 pb-1">
    <div class="container">
        <h1><?php echo e($text); ?>

            <a href="#" data-toggle="modal" data-target="#createModal" id="openCreateModal">
            <svg class="bi bi-plus-circle-fill" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd" d="M16 8A8 8 0 110 8a8 8 0 0116 0zM8.5 4a.5.5 0 00-1 0v3.5H4a.5.5 0 000 1h3.5V12a.5.5 0 001 0V8.5H12a.5.5 0 000-1H8.5V4z" clip-rule="evenodd"/>
            </svg>
            </a>
        </h1>
    </div>
</section>
<?php /**PATH /home/projects/words.loc/resources/views/blocks/h1.blade.php ENDPATH**/ ?>