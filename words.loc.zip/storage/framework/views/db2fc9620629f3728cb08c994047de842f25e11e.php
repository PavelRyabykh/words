<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('blocks.h1', ['text' => $category->name], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('modals.create-word', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('modals.update-word', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <table class="table table-dark mt-3">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Слово</th>
            <th scope="col">Транскрипция</th>
            <th scope="col">Перевод</th>
            <th scope="col" class="text-center">Пример</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        <?php echo $__env->renderEach('blocks.word', $words, 'word'); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/projects/words.loc/resources/views/category.blade.php ENDPATH**/ ?>