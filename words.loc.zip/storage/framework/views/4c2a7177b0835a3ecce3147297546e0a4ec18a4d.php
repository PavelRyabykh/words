<?php $__env->startSection('title', 'Categories'); ?>
<?php $__env->startSection('content'); ?>
    <main role="main">
        <?php echo $__env->make('blocks.h1', ['text' => 'Категории'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('modals.update-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('modals.create-category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="album bg-light pt-1">
            <div class="container">
                <div id="row" class="row">
                    <?php echo $__env->renderEach('blocks.category', $categories, 'category'); ?>
                </div>
            </div>
        </div>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/projects/words.loc/resources/views/main.blade.php ENDPATH**/ ?>