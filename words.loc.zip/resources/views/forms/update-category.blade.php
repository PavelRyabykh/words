<form id="updateForm" action="">
    <div class="form-group">
        <label for="exampleInputEmail1">Имя категории</label>
        <input type="text" name="name" class="form-control">
        <input type="hidden" name="id" class="form-control">
    </div>
</form>
