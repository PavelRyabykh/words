<form id="createCategoryForm">
    <div class="form-group">
        <label for="exampleInputEmail1">Имя категории</label>
        <input type="text" name="name" class="form-control">
    </div>
</form>
